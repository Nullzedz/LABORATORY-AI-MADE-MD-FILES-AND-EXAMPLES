#ifndef FIREPOKEMON_H_INCLUDED
#define FIREPOKEMON_H_INCLUDED

#include "pokemon.h"

class FirePokemon : public Pokemon
{
public:
    FirePokemon();
    FirePokemon(string, int, int);  // name, level, maxHp
    void   setBurnChance(int);
    void   setFirePower(double);
    int    getBurnChance();
    double getFirePower();
    void   attack(Pokemon&);
    void   useFlamethrower(Pokemon&);
    ~FirePokemon();

private:
    int    burnChance;   // burn probability 0-100
    double firePower;    // damage multiplier
};

#endif // FIREPOKEMON_H_INCLUDED
