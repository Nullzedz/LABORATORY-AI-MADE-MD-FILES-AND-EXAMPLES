#include "firePokemon.h"
#include <iostream>
#include <cstdlib>   // rand()
using namespace std;

// --- Constructors ---
FirePokemon::FirePokemon() : Pokemon()
{
    burnChance = 0;
    firePower  = 1.0;
}

FirePokemon::FirePokemon(string n, int lv, int mhp)
    : Pokemon(n, lv, mhp)
{
    burnChance = 20;    // sensible default: 20 % burn chance
    firePower  = 1.5;   // sensible default: 1.5x multiplier
    setType("Fire");
}

// --- Setters ---
void FirePokemon::setBurnChance(int bc) { burnChance = bc; }
void FirePokemon::setFirePower(double fp) { firePower = fp; }

// --- Getters ---
int    FirePokemon::getBurnChance() { return burnChance; }
double FirePokemon::getFirePower()  { return firePower;  }

// --- attack (overridden) ---
void FirePokemon::attack(Pokemon& target)
{
    int damage = static_cast<int>(level * 2 * firePower);
    int newHp  = target.getHp() - damage;
    if (newHp < 0) newHp = 0;
    target.setHp(newHp);
    cout << name << " uses a fire attack on " << target.getName()
         << " for " << damage << " damage!" << endl;

    // Burn chance check
    int roll = rand() % 100;
    if (roll < burnChance)
    {
        int burnDmg = target.getMaxHp() / 10;
        int burned  = target.getHp() - burnDmg;
        if (burned < 0) burned = 0;
        target.setHp(burned);
        cout << target.getName() << " is burned and takes "
             << burnDmg << " additional damage!" << endl;
    }

    if (!target.isAlive())
        cout << target.getName() << " fainted!" << endl;
}

// --- useFlamethrower ---
void FirePokemon::useFlamethrower(Pokemon& target)
{
    int damage = static_cast<int>(level * 2 * firePower * 2);  // double fire damage
    int newHp  = target.getHp() - damage;
    if (newHp < 0) newHp = 0;
    target.setHp(newHp);
    cout << name << " uses Flamethrower on " << target.getName()
         << " for " << damage << " damage!" << endl;

    // Flamethrower always attempts burn
    int burnDmg = target.getMaxHp() / 10;
    int burned  = target.getHp() - burnDmg;
    if (burned < 0) burned = 0;
    target.setHp(burned);
    cout << target.getName() << " is burned by the intense flames and takes "
         << burnDmg << " burn damage!" << endl;

    if (!target.isAlive())
        cout << target.getName() << " fainted!" << endl;
}

// --- Destructor ---
FirePokemon::~FirePokemon()
{
}
