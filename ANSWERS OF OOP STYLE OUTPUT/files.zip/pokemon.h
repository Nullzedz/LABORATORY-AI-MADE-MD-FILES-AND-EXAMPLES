#ifndef POKEMON_H_INCLUDED
#define POKEMON_H_INCLUDED

#include <string>
using namespace std;

class Pokemon
{
public:
    Pokemon();
    Pokemon(string, int, int);  // name, level, maxHp
    void   setName(string);
    void   setLevel(int);
    void   setHp(int);
    void   setType(string);
    string getName();
    int    getLevel();
    int    getHp();
    int    getMaxHp();
    string getType();
    bool   isAlive();
    virtual void attack(Pokemon&);
    void   displayStats();
    ~Pokemon();

protected:
    string name;
    int    level;
    int    hp;
    int    maxHp;
    string type;
};

#endif // POKEMON_H_INCLUDED
