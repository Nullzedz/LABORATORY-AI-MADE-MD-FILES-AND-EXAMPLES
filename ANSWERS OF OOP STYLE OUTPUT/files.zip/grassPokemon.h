#ifndef GRASSPOKEMON_H_INCLUDED
#define GRASSPOKEMON_H_INCLUDED

#include "pokemon.h"

class GrassPokemon : public Pokemon
{
public:
    GrassPokemon();
    GrassPokemon(string, int, int);  // name, level, maxHp
    void   setHealAmount(int);
    void   setPoisonChance(double);
    int    getHealAmount();
    double getPoisonChance();
    void   attack(Pokemon&);
    void   regenerate();
    ~GrassPokemon();

private:
    int    healAmount;    // HP restored per regeneration
    double poisonChance;  // 0.0 – 1.0
};

#endif // GRASSPOKEMON_H_INCLUDED
