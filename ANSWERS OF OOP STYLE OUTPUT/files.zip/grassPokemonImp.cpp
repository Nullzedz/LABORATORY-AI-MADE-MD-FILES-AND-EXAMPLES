#include "grassPokemon.h"
#include <iostream>
#include <cstdlib>   // rand()
using namespace std;

// --- Constructors ---
GrassPokemon::GrassPokemon() : Pokemon()
{
    healAmount   = 0;
    poisonChance = 0.0;
}

GrassPokemon::GrassPokemon(string n, int lv, int mhp)
    : Pokemon(n, lv, mhp)
{
    healAmount   = mhp / 10;  // heals 10% of maxHp by default
    poisonChance = 0.30;      // 30 % chance to poison
    setType("Grass");
}

// --- Setters ---
void GrassPokemon::setHealAmount(int ha)      { healAmount   = ha; }
void GrassPokemon::setPoisonChance(double pc) { poisonChance = pc; }

// --- Getters ---
int    GrassPokemon::getHealAmount()   { return healAmount;   }
double GrassPokemon::getPoisonChance() { return poisonChance; }

// --- attack (overridden) ---
void GrassPokemon::attack(Pokemon& target)
{
    int damage = level * 2;
    int newHp  = target.getHp() - damage;
    if (newHp < 0) newHp = 0;
    target.setHp(newHp);
    cout << name << " uses a grass attack on " << target.getName()
         << " for " << damage << " damage!" << endl;

    // Poison check (0-99 roll vs poisonChance * 100)
    int roll = rand() % 100;
    if (roll < static_cast<int>(poisonChance * 100))
    {
        int poisonDmg = target.getMaxHp() / 8;
        int poisoned  = target.getHp() - poisonDmg;
        if (poisoned < 0) poisoned = 0;
        target.setHp(poisoned);
        cout << target.getName() << " is poisoned and takes "
             << poisonDmg << " poison damage!" << endl;
    }

    if (!target.isAlive())
        cout << target.getName() << " fainted!" << endl;
}

// --- regenerate ---
void GrassPokemon::regenerate()
{
    int healed = healAmount;
    int newHp  = hp + healed;
    if (newHp > maxHp)
    {
        healed = maxHp - hp;
        newHp  = maxHp;
    }
    hp = newHp;
    cout << name << " regenerates and recovers " << healed << " HP! "
         << "(HP: " << hp << " / " << maxHp << ")" << endl;
}

// --- Destructor ---
GrassPokemon::~GrassPokemon()
{
}
