#include "pokemon.h"
#include <iostream>
using namespace std;

// --- Constructors ---
Pokemon::Pokemon()
{
    name  = "";
    level = 0;
    hp    = 0;
    maxHp = 0;
    type  = "";
}

Pokemon::Pokemon(string n, int lv, int mhp)
{
    name  = n;
    level = lv;
    maxHp = mhp;
    hp    = mhp;   // starts at full HP
    type  = "";
}

// --- Setters ---
void Pokemon::setName(string n)  { name  = n; }
void Pokemon::setLevel(int lv)   { level = lv; }
void Pokemon::setHp(int h)       { hp    = h; }
void Pokemon::setType(string t)  { type  = t; }

// --- Getters ---
string Pokemon::getName()  { return name;  }
int    Pokemon::getLevel() { return level; }
int    Pokemon::getHp()    { return hp;    }
int    Pokemon::getMaxHp() { return maxHp; }
string Pokemon::getType()  { return type;  }

// --- isAlive ---
bool Pokemon::isAlive()
{
    return hp > 0;
}

// --- attack (base: deals level-based damage) ---
void Pokemon::attack(Pokemon& target)
{
    int damage = level * 2;
    int newHp  = target.getHp() - damage;
    if (newHp < 0) newHp = 0;
    target.setHp(newHp);
    cout << name << " attacks " << target.getName()
         << " for " << damage << " damage!" << endl;
    if (!target.isAlive())
        cout << target.getName() << " fainted!" << endl;
}

// --- displayStats ---
void Pokemon::displayStats()
{
    cout << "Name : " << name  << endl;
    cout << "Type : " << type  << endl;
    cout << "Level: " << level << endl;
    cout << "HP   : " << hp << " / " << maxHp << endl;
}

// --- Destructor ---
Pokemon::~Pokemon()
{
}
