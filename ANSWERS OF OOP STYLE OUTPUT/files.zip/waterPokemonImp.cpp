#include "waterPokemon.h"
#include <iostream>
using namespace std;

// --- Constructors ---
WaterPokemon::WaterPokemon() : Pokemon()
{
    waterPressure = 1;
    canDive       = false;
}

WaterPokemon::WaterPokemon(string n, int lv, int mhp)
    : Pokemon(n, lv, mhp)
{
    waterPressure = 5;     // sensible default: mid-range pressure
    canDive       = false;
    setType("Water");
}

// --- Setters ---
void WaterPokemon::setWaterPressure(int wp) { waterPressure = wp; }
void WaterPokemon::setCanDive(bool cd)       { canDive       = cd; }

// --- Getters ---
int  WaterPokemon::getWaterPressure() { return waterPressure; }
bool WaterPokemon::getCanDive()       { return canDive;       }

// --- attack (overridden) ---
void WaterPokemon::attack(Pokemon& target)
{
    // Base damage scaled by waterPressure (1-10)
    int damage = level * waterPressure / 5 * 2;
    if (damage < 1) damage = 1;

    // Bonus against Fire-type opponents
    if (target.getType() == "Fire")
    {
        damage = static_cast<int>(damage * 2.0);
        cout << "It's super effective against Fire type!" << endl;
    }

    int newHp = target.getHp() - damage;
    if (newHp < 0) newHp = 0;
    target.setHp(newHp);
    cout << name << " uses a water attack on " << target.getName()
         << " for " << damage << " damage!" << endl;

    if (!target.isAlive())
        cout << target.getName() << " fainted!" << endl;
}

// --- useHydroBlast ---
void WaterPokemon::useHydroBlast(Pokemon& target)
{
    int damage = level * waterPressure / 3 * 2;
    if (damage < 1) damage = 1;

    int newHp = target.getHp() - damage;
    if (newHp < 0) newHp = 0;
    target.setHp(newHp);
    cout << name << " uses Hydro Blast on " << target.getName()
         << " for " << damage << " damage!" << endl;

    if (canDive)
        cout << name << " dives underwater, gaining an evasion bonus!" << endl;

    if (!target.isAlive())
        cout << target.getName() << " fainted!" << endl;
}

// --- Destructor ---
WaterPokemon::~WaterPokemon()
{
}
