#ifndef WATERPOKEMON_H_INCLUDED
#define WATERPOKEMON_H_INCLUDED

#include "pokemon.h"

class WaterPokemon : public Pokemon
{
public:
    WaterPokemon();
    WaterPokemon(string, int, int);  // name, level, maxHp
    void setWaterPressure(int);
    void setCanDive(bool);
    int  getWaterPressure();
    bool getCanDive();
    void attack(Pokemon&);
    void useHydroBlast(Pokemon&);
    ~WaterPokemon();

private:
    int  waterPressure;  // 1-10
    bool canDive;
};

#endif // WATERPOKEMON_H_INCLUDED
