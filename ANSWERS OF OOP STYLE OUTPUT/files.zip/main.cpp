#include <iostream>
#include "pokemon.h"
#include "firePokemon.h"
#include "waterPokemon.h"
#include "grassPokemon.h"
using namespace std;

int main()
{
    // =========================================================
    // --- Test FirePokemon ---
    // =========================================================
    cout << "=== FirePokemon ===" << endl;

    FirePokemon charmander("Charmander", 10, 100);
    charmander.setBurnChance(30);
    charmander.setFirePower(1.8);

    charmander.displayStats();
    cout << "BurnChance : " << charmander.getBurnChance() << endl;
    cout << "FirePower  : " << charmander.getFirePower()  << endl;
    cout << endl;

    // Default constructor test
    FirePokemon defaultFire;
    defaultFire.setName("FireDefault");
    defaultFire.setLevel(1);
    defaultFire.setType("Fire");
    defaultFire.displayStats();
    cout << endl;

    // =========================================================
    // --- Test WaterPokemon ---
    // =========================================================
    cout << "=== WaterPokemon ===" << endl;

    WaterPokemon squirtle("Squirtle", 10, 110);
    squirtle.setWaterPressure(8);
    squirtle.setCanDive(true);

    squirtle.displayStats();
    cout << "WaterPressure: " << squirtle.getWaterPressure() << endl;
    cout << "CanDive      : " << (squirtle.getCanDive() ? "Yes" : "No") << endl;
    cout << endl;

    // =========================================================
    // --- Test GrassPokemon ---
    // =========================================================
    cout << "=== GrassPokemon ===" << endl;

    GrassPokemon bulbasaur("Bulbasaur", 10, 105);
    bulbasaur.setHealAmount(15);
    bulbasaur.setPoisonChance(0.40);

    bulbasaur.displayStats();
    cout << "HealAmount  : " << bulbasaur.getHealAmount()   << endl;
    cout << "PoisonChance: " << bulbasaur.getPoisonChance() << endl;
    cout << endl;

    // =========================================================
    // --- Simulate attack sequence ---
    // =========================================================
    cout << "=== Battle Simulation ===" << endl;

    // Fire vs Water (Water should get super-effective bonus)
    cout << "--- Water attacks Fire ---" << endl;
    squirtle.attack(charmander);
    charmander.displayStats();
    cout << endl;

    // Fire attacks Water with Flamethrower
    cout << "--- Fire uses Flamethrower on Water ---" << endl;
    charmander.useFlamethrower(squirtle);
    squirtle.displayStats();
    cout << endl;

    // Grass attacks Water
    cout << "--- Grass attacks Water ---" << endl;
    bulbasaur.attack(squirtle);
    squirtle.displayStats();
    cout << endl;

    // Grass uses HydroBlast (Water special)
    cout << "--- Water uses HydroBlast on Grass ---" << endl;
    squirtle.useHydroBlast(bulbasaur);
    bulbasaur.displayStats();
    cout << endl;

    // Grass regenerates
    cout << "--- Grass regenerates ---" << endl;
    bulbasaur.regenerate();
    cout << endl;

    // isAlive check
    cout << "=== isAlive Checks ===" << endl;
    cout << "Charmander alive? " << (charmander.isAlive() ? "Yes" : "No") << endl;
    cout << "Squirtle alive?   " << (squirtle.isAlive()   ? "Yes" : "No") << endl;
    cout << "Bulbasaur alive?  " << (bulbasaur.isAlive()  ? "Yes" : "No") << endl;

    return 0;
}
